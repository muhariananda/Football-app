package com.aria.footballapp.data.source.remote

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aria.footballapp.BuildConfig
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.data.source.local.entity.TeamsEntity
import com.aria.footballapp.data.source.remote.respon.AllEventResponse
import com.aria.footballapp.data.source.remote.respon.EventResponse
import com.aria.footballapp.data.source.remote.respon.LeagueResponse
import com.aria.footballapp.data.source.remote.respon.TeamsResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RemoteRepository(private val api: ApiService) {

    companion object {
        fun instance(): RemoteRepository {
            val retrofit: Retrofit = Retrofit.Builder()
                .baseUrl(BuildConfig.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return RemoteRepository(retrofit.create(ApiService::class.java))
        }
    }


    //League
    fun getDetailLeague(leagueId: String): LiveData<LeaguesEntity> {
        val leagueResult = MutableLiveData<LeaguesEntity>()
        api.getLeague(leagueId).enqueue(object : Callback<LeagueResponse> {
            override fun onResponse(
                call: Call<LeagueResponse>,
                response: Response<LeagueResponse>
            ) {
                if (response.isSuccessful) {
                    leagueResult.value = response.body()?.leagues?.get(0)
                }
            }

            override fun onFailure(call: Call<LeagueResponse>, t: Throwable) {

            }
        })
        return leagueResult
    }


    //Events
    fun getNextEvent(leagueId: String): LiveData<List<EventsEntity>> {
        val eventResult = MutableLiveData<List<EventsEntity>>()
        api.getNextEvent(leagueId).enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                if (response.isSuccessful) {
                    eventResult.value = response.body()?.events
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                Log.d("TAG", "onFailure")
            }
        })

        return eventResult
    }

    fun getLastEvent(leagueId: String): LiveData<List<EventsEntity>> {
        val eventResult = MutableLiveData<List<EventsEntity>>()
        api.getLastEvent(leagueId).enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                if (response.isSuccessful) {
                    eventResult.value = response.body()?.events
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {

            }
        })
        return eventResult
    }

    fun getSearchEvent(team: String): LiveData<List<EventsEntity>> {
        val eventResult = MutableLiveData<List<EventsEntity>>()

        api.getSearchEvent(team).enqueue(object : Callback<AllEventResponse> {
            override fun onResponse(
                call: Call<AllEventResponse>,
                response: Response<AllEventResponse>
            ) {
                if (response.isSuccessful) {
                    eventResult.value = response.body()?.event
                }
            }

            override fun onFailure(call: Call<AllEventResponse>, t: Throwable) {

            }
        })
        return eventResult
    }

    fun getDetailEvent(eventId: String?): LiveData<EventsEntity> {
        val eventResult = MutableLiveData<EventsEntity>()
        api.getDetailEvent(eventId).enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                if (response.isSuccessful) {
                    eventResult.value = response.body()?.events?.get(0)
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {

            }
        })
        return eventResult
    }

    //Teams
    fun getAllTeams(league: String): LiveData<List<TeamsEntity>> {
        val teamResult = MutableLiveData<List<TeamsEntity>>()
        api.getAllTeam(league).enqueue(object : Callback<TeamsResponse> {
            override fun onResponse(call: Call<TeamsResponse>, response: Response<TeamsResponse>) {
                if (response.isSuccessful) {
                    teamResult.value = response.body()?.teams
                }
            }

            override fun onFailure(call: Call<TeamsResponse>, t: Throwable) {

            }
        })
        return teamResult
    }

    fun getDetailTeam(teamId: String): LiveData<TeamsEntity> {
        val teamResult = MutableLiveData<TeamsEntity>()
        api.getDetailTeam(teamId).enqueue(object : Callback<TeamsResponse> {
            override fun onResponse(call: Call<TeamsResponse>, response: Response<TeamsResponse>) {
                if (response.isSuccessful) {
                    teamResult.value = response.body()?.teams?.get(0)
                }
            }

            override fun onFailure(call: Call<TeamsResponse>, t: Throwable) {

            }
        })
        return teamResult
    }
}