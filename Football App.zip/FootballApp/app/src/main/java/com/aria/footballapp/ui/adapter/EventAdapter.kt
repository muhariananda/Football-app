package com.aria.footballapp.ui.adapter

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.ui.event.DetailEventActivity
import kotlinx.android.synthetic.main.list_event.view.*
import org.jetbrains.anko.startActivity
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class EventAdapter(private val context: Context) :
    RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    private val events: MutableList<EventsEntity> = ArrayList()

    fun setList(items: List<EventsEntity>) {
        this.events.clear()
        this.events.addAll(items)
    }

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTeamHome = itemView.tv_team_home
        private val tvTeamAway = itemView.tv_team_away
        private val tvScoreHome = itemView.tv_score_home
        private val tvScoreAway = itemView.tv_score_away
        private val tvDate = itemView.tv_next_date
        private val tvTime = itemView.tv_next_time
        private val imgArrowHome = itemView.arrow_home
        private val imgArrowAway = itemView.arrow_away

        fun bindItems(context: Context, event: EventsEntity) {

            val timeConvert = toGMTFormat(event.dateEvent, event.strTime)
            val formatDate = SimpleDateFormat("E, dd/MM")
            val formatTime = SimpleDateFormat("HH:mm")
            val date = formatDate.format(timeConvert)
            val time = formatTime.format(timeConvert)

            tvTeamHome.text = event.strHomeTeam
            tvTeamAway.text = event.strAwayTeam
            tvScoreHome.text = event.intHomeScore
            tvScoreAway.text = event.intAwayScore
            tvDate.text = date
            tvTime.text = time

            itemView.setOnClickListener {
                context.startActivity<DetailEventActivity>(
                    "id" to event.idEvent,
                    "home" to event.idHomeTeam,
                    "away" to event.idAwayTeam)
            }

            if (event.intHomeScore == null && event.intAwayScore == null) {
                tvScoreHome.visibility = View.GONE
                tvScoreAway.visibility = View.GONE
                imgArrowHome.visibility = View.GONE
                imgArrowAway.visibility = View.GONE

            } else if (event.intHomeScore == event.intAwayScore) {
                imgArrowHome.visibility = View.INVISIBLE
                imgArrowAway.visibility = View.INVISIBLE

            } else if (event.intHomeScore!! > event.intAwayScore!!) {
                tvTeamHome.setTypeface(tvTeamHome.typeface, Typeface.BOLD)
                tvScoreHome.setTypeface(tvScoreHome.typeface, Typeface.BOLD)
                imgArrowAway.visibility = View.INVISIBLE
            } else {
                tvTeamAway.setTypeface(tvTeamAway.typeface, Typeface.BOLD)
                tvScoreAway.setTypeface(tvScoreAway.typeface, Typeface.BOLD)
                imgArrowHome.visibility = View.INVISIBLE
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): EventAdapter.EventViewHolder {
        return EventViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.list_event,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return events.size
    }

    override fun onBindViewHolder(holder: EventAdapter.EventViewHolder, position: Int) {
        holder.bindItems(context, events[position])
    }

}

private fun toGMTFormat(date: String?, time: String?): Date {
    val convert = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    convert.timeZone = TimeZone.getTimeZone("UTC")
    val dateTime = "$date $time"
    return convert.parse(dateTime)
}