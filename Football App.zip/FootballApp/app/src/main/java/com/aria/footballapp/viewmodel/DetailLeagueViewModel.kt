package com.aria.footballapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.data.source.local.entity.LeaguesEntity

class DetailLeagueViewModel(private val footballRepository: FootballRepository?) : ViewModel() {

    var data: LiveData<LeaguesEntity>? = null

    fun init(leagueId: String) {
        if (data != null) {
            return
        }

        data = footballRepository?.getDetailLeague(leagueId)
    }

    fun getDetailLeague(): LiveData<LeaguesEntity>? {
        return data
    }
}