package com.aria.footballapp.ui.team

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.TeamsEntity
import com.aria.footballapp.viewmodel.DetailTeamViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_team.*

class DetailTeamActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvDescription: TextView
    private lateinit var imgBadge: ImageView
    private lateinit var imgBanner: ImageView
    private lateinit var progressBar: ProgressBar

    private lateinit var viewModel: DetailTeamViewModel

    companion object {
        fun obtainViewModel(activity: AppCompatActivity): DetailTeamViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(DetailTeamViewModel::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_team)

        initUI()
        showLoading(true)

        val teamId = intent.getStringExtra("id")

        viewModel = obtainViewModel(this)

        viewModel.initTeam(teamId)
        viewModel.getTeams()?.observe(this, Observer { team ->
            if (team != null) {
                populateTeams(team)
                showLoading(false)
            } else {
                showLoading(false)
                showError()
            }

        })
    }

    private fun initUI() {
        tvName = tv_team_name
        tvLocation = tv_team_location
        tvDescription = tv_team_description
        imgBadge = img_team_badge
        imgBanner = img_team_banner
        progressBar = progress_bar
    }

    private fun populateTeams(team: TeamsEntity) {
        tvName.text = team.strTeam
        tvLocation.text = team.strStadiumLocation
        tvDescription.text = team.strDescriptionEN

        team.strTeamBadge?.let { Picasso.get().load(it).fit().into(imgBadge) }
        team.strStadiumThumb?.let { Picasso.get().load(it).fit().into(imgBanner) }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    private fun showError() {
        Toast.makeText(this, "Please check your connection", Toast.LENGTH_SHORT).show()
    }
}
