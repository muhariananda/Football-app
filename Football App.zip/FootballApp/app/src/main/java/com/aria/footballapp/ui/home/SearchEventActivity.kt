package com.aria.footballapp.ui.home

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.ui.adapter.EventSearchAdapter
import com.aria.footballapp.viewmodel.EventSearchViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.activity_serach_event.*

class SearchEventActivity : AppCompatActivity() {

    private lateinit var adapter: EventSearchAdapter
    private lateinit var viewModel: EventSearchViewModel

    private lateinit var recyclerView: RecyclerView
    private lateinit var searchView: SearchView
    private lateinit var progressBar: ProgressBar

    companion object {
        fun obtainViewModel(activity: AppCompatActivity): EventSearchViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(EventSearchViewModel::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_serach_event)
        setToolbar()

        recyclerView = rv_search
        progressBar = progress_bar
        adapter = EventSearchAdapter(this)
        viewModel = obtainViewModel(this)

        searchView = search_view
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                showLoading(true)
                getEvent(newText)
                return false
            }
        })

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

    }

    private fun getEvent(query: String) {
        viewModel.init(query)
        viewModel.getSearchEvent()?.observe(this, Observer { event ->
            if (event == null) {
                showError()
                showLoading(false)
            } else {
                adapter.setList(event)
                adapter.notifyDataSetChanged()
                showLoading(false)
            }

        })
    }

    private fun setToolbar() {
        val toolbar = toolbar
        setSupportActionBar(toolbar)

        if (supportActionBar != null) {
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayShowHomeEnabled(true)
            supportActionBar?.setDisplayShowTitleEnabled(false)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
            recyclerView.visibility = View.INVISIBLE
        } else {
            progressBar.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun showError() {
        Toast.makeText(this, "Match not Found", Toast.LENGTH_SHORT).show()
    }
}
