package com.aria.footballapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.data.source.local.entity.TeamsEntity

class DetailEventViewModel(private val footballRepository: FootballRepository?) : ViewModel() {

    var data: LiveData<EventsEntity>? = null
    var teamHome: LiveData<TeamsEntity>? = null
    var teamAway: LiveData<TeamsEntity>? = null

    fun initEvent(eventId: String) {
        if (data != null) {
            return
        }

        data = footballRepository?.getDetailEvent(eventId)
    }

    fun initTeam(idTeamHome: String, idTeamAway: String) {
        if (teamHome != null && teamAway != null) {
            return
        }

        teamHome = footballRepository?.getDetailTeam(idTeamHome)
        teamAway = footballRepository?.getDetailTeam(idTeamAway)
    }

    fun getDetailEvent(): LiveData<EventsEntity>? {
        return data
    }

    fun getHomeBadge(): LiveData<TeamsEntity>? {
        return teamHome
    }

    fun getAwayBadge(): LiveData<TeamsEntity>? {
        return teamAway
    }
}