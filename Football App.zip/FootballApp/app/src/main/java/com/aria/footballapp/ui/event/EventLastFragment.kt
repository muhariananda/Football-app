package com.aria.footballapp.ui.event


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.ui.adapter.EventAdapter
import com.aria.footballapp.viewmodel.EventLastViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.fragment_last_match.view.*

/**
 * A simple [Fragment] subclass.
 */
class EventLastFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var viewModel: EventLastViewModel

    private var list: ArrayList<EventsEntity> = ArrayList()

    companion object {
        private var leagueId: String = ""
        fun create(id: String): EventLastFragment {
            leagueId = id
            return EventLastFragment()
        }

        fun obtainViewModel(activity: FragmentActivity): EventLastViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(EventLastViewModel::class.java)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_last_match, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.cv_events
        progressBar = view.progressBar
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            showLoading(true)

            val adapter = context?.let { EventAdapter(it) }
            viewModel = obtainViewModel(activity!!)

            viewModel.initLast(leagueId)
            viewModel.getLastEvent()?.observe(this, Observer { events ->
                if (events != null) {
                    list.addAll(events)
                    adapter?.setList(list)
                    adapter?.notifyDataSetChanged()
                    showLoading(false)
                }
            })

            recyclerView.layoutManager = LinearLayoutManager(context)
            recyclerView.adapter = adapter
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

}
