package com.aria.footballapp.ui.home

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.ui.adapter.HomeAdapter
import com.aria.footballapp.viewmodel.HomeViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity

class HomeActivity : AppCompatActivity() {

    private var list: ArrayList<LeaguesEntity> = ArrayList()

    private lateinit var progressBar: ProgressBar

    companion object {
        fun obtainViewModel(activity: AppCompatActivity): HomeViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(HomeViewModel::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = progress_bar
        showLoading(true)

        val adapter =
            HomeAdapter(this)

        val viewModel = obtainViewModel(this)

        viewModel.initLeague()
        viewModel.getLeague()?.observe(this, Observer {
            list.addAll(it)
            adapter.setList(list)
            adapter.notifyDataSetChanged()
            showLoading(false)
        })

        rv_league_list.layoutManager = LinearLayoutManager(this)
        rv_league_list.adapter = adapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_search, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_seach) {
            startActivity<SearchEventActivity>()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }
}
