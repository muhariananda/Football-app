package com.aria.footballapp.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.TeamsEntity
import com.aria.footballapp.ui.team.DetailTeamActivity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.list_teams.view.*
import org.jetbrains.anko.startActivity

class TeamAdapter(private val context: Context) :
    RecyclerView.Adapter<TeamAdapter.TeamViewHolder>() {

    private val teams: MutableList<TeamsEntity> = ArrayList()

    class TeamViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle = itemView.tv_team_item_name
        private val imgBadge = itemView.img_team_item_badge

        fun bindItem(context: Context, team: TeamsEntity) {
            tvTitle.text = team.strTeam
            team.strTeamBadge?.let { Picasso.get().load(it).fit().into(imgBadge) }
            itemView.setOnClickListener {
                context.startActivity<DetailTeamActivity>("id" to team.idTeam)
            }
        }
    }

    fun setList(items: List<TeamsEntity>) {
        this.teams.clear()
        this.teams.addAll(items)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamAdapter.TeamViewHolder {
        return TeamViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.list_teams,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return teams.size
    }

    override fun onBindViewHolder(holder: TeamAdapter.TeamViewHolder, position: Int) {
        holder.bindItem(context, teams[position])
    }
}