package com.aria.footballapp.ui.event


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.ui.adapter.EventAdapter
import com.aria.footballapp.viewmodel.EventNextViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.fragment_next_match.view.*

/**
 * A simple [Fragment] subclass.
 */
class EventNextFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar

    companion object {
        private var leagueId: String = ""
        fun create(id: String): EventNextFragment {
            leagueId = id
            return EventNextFragment()
        }

        fun obtainViewModel(activity: FragmentActivity): EventNextViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(EventNextViewModel::class.java)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_next_match, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.rv_events
        progressBar = view.progressBar
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            showLoading(true)

            val adapter = context?.let { EventAdapter(it) }
            val viewModel = obtainViewModel(activity!!)

            viewModel.initNextEvent(leagueId)
            viewModel.getNextEvent()?.observe(this, Observer { events ->
                adapter?.setList(events)
                adapter?.notifyDataSetChanged()
                showLoading(false)
            })

            recyclerView.layoutManager = LinearLayoutManager(context)
            recyclerView.adapter = adapter
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }
}
