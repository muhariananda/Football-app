package com.aria.footballapp.data.source

import androidx.lifecycle.LiveData
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.data.source.local.entity.TeamsEntity

interface FootballDataSource {

    fun getAllLeague(): LiveData<List<LeaguesEntity>>

    fun getDetailLeague(leagueId: String): LiveData<LeaguesEntity>

    fun getNextEvent(leagueId: String): LiveData<List<EventsEntity>>

    fun getLastEvent(leagueId: String): LiveData<List<EventsEntity>>

    fun getSearchEvent(team: String): LiveData<List<EventsEntity>>

    fun getDetailEvent(eventId: String?): LiveData<EventsEntity>

    fun getAllTeams(league: String): LiveData<List<TeamsEntity>>

    fun getDetailTeam(teamId: String): LiveData<TeamsEntity>
}