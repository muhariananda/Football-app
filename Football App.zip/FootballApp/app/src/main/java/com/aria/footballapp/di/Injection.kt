package com.aria.footballapp.di

import android.app.Application
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.data.source.remote.RemoteRepository

class Injection {
    companion object {
        fun provideRepository(application: Application): FootballRepository? {
            val remoteRepository = RemoteRepository.instance()

            return FootballRepository.instance(remoteRepository)
        }
    }
}