package com.aria.footballapp.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.data.source.local.entity.TeamsEntity
import com.aria.footballapp.data.source.remote.RemoteRepository
import com.aria.footballapp.utils.DataDummy

class FootballRepository(private val remoteRepository: RemoteRepository) : FootballDataSource {

    init {
        INSTANCE
    }

    companion object {
        private var INSTANCE: FootballRepository? = null

        fun instance(remoteRepository: RemoteRepository): FootballRepository? {
            if (INSTANCE == null) {
                synchronized(FootballRepository::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = FootballRepository(remoteRepository)
                    }
                }
            }
            return INSTANCE
        }
    }


    override fun getAllLeague(): LiveData<List<LeaguesEntity>> {
        val data = MutableLiveData<List<LeaguesEntity>>()
        data.value = DataDummy.generateAllLeague()

        return data
    }

    override fun getDetailLeague(leagueId: String): LiveData<LeaguesEntity> {
        return remoteRepository.getDetailLeague(leagueId)
    }

    override fun getNextEvent(leagueId: String): LiveData<List<EventsEntity>> {
        return remoteRepository.getNextEvent(leagueId)
    }

    override fun getLastEvent(leagueId: String): LiveData<List<EventsEntity>> {
        return remoteRepository.getLastEvent(leagueId)
    }

    override fun getSearchEvent(team: String): LiveData<List<EventsEntity>> {
        return remoteRepository.getSearchEvent(team)
    }

    override fun getDetailEvent(eventId: String?): LiveData<EventsEntity> {
        return remoteRepository.getDetailEvent(eventId)
    }

    override fun getAllTeams(league: String): LiveData<List<TeamsEntity>> {
        return remoteRepository.getAllTeams(league)
    }

    override fun getDetailTeam(teamId: String): LiveData<TeamsEntity> {
        return remoteRepository.getDetailTeam(teamId)
    }
}