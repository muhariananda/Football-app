package com.aria.footballapp.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.di.Injection

class ViewModelFactory(private val footballRepository: FootballRepository?) :
    ViewModelProvider.NewInstanceFactory() {

    init {
        INSTANCE
    }

    companion object {
        private var INSTANCE: ViewModelFactory? = null
        fun instance(application: Application): ViewModelFactory? {
            if (INSTANCE == null) {
                synchronized(ViewModelFactory::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = ViewModelFactory(Injection.provideRepository(application))
                    }
                }
            }
            return INSTANCE
        }
    }

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> {
                HomeViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(DetailLeagueViewModel::class.java) -> {
                DetailLeagueViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(TeamsViewModel::class.java) -> {
                TeamsViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(EventNextViewModel::class.java) -> {
                EventNextViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(EventLastViewModel::class.java) -> {
                EventLastViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(DetailEventViewModel::class.java) -> {
                DetailEventViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(DetailTeamViewModel::class.java) -> {
                DetailTeamViewModel(footballRepository) as T
            }
            modelClass.isAssignableFrom(EventSearchViewModel::class.java) -> {
                EventSearchViewModel(footballRepository) as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel class: $modelClass")
        }

    }
}