package com.aria.footballapp.ui.league

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.ViewPager
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.ui.adapter.TabAdapter
import com.aria.footballapp.ui.event.EventLastFragment
import com.aria.footballapp.ui.event.EventNextFragment
import com.aria.footballapp.ui.team.TeamFragment
import com.aria.footballapp.viewmodel.DetailLeagueViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import com.google.android.material.tabs.TabLayout
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_league.*
import kotlinx.android.synthetic.main.container_cv_detail_league.*

class DetailLeagueActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvCountry: TextView
    private lateinit var imgBadge: ImageView
    private lateinit var imgBanner: ImageView
    private lateinit var mTabLayout: TabLayout
    private lateinit var mViewPager: ViewPager

    private lateinit var viewModel: DetailLeagueViewModel

    private var league: String = ""
    private var leagueId: String = ""

    companion object {
        fun obtainViewModel(activity: AppCompatActivity): DetailLeagueViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(DetailLeagueViewModel::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_league)

        tvName = tv_detail_league
        tvCountry = tv_detail_country
        imgBadge = img_detail_badge
        imgBanner = img_banner

        mTabLayout = tab_layout
        mViewPager = view_pager

        league = intent.getStringExtra("league")
        leagueId = intent.getStringExtra("id")

        viewModel =
            obtainViewModel(
                this
            )

        viewModel.init(leagueId)
        viewModel.getDetailLeague()?.observe(this, Observer { leagues ->
            if (leagues != null) {
                populateLeague(leagues)
            }
        })


        getViewPager()
    }

    private fun getViewPager() {
        val adapter = TabAdapter(supportFragmentManager)
        adapter.addFragment(DetailInformationFragment.create(leagueId), "Detail")
        adapter.addFragment(TeamFragment.create(league), "Team")
        adapter.addFragment(EventLastFragment.create(leagueId), "Last match")
        adapter.addFragment(EventNextFragment.create(leagueId), "Next match")
        mViewPager.adapter = adapter
        mTabLayout.setupWithViewPager(mViewPager)
    }

    private fun populateLeague(league: LeaguesEntity) {
        tvName.text = league.strLeague
        tvCountry.text = league.strCountry
        league.strBadge?.let { Picasso.get().load(it).fit().into(imgBadge) }
        league.strFanart2?.let { Picasso.get().load(it).fit().into(imgBanner) }
    }
}
