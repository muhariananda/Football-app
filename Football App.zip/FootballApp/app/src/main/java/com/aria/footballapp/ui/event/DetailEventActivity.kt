package com.aria.footballapp.ui.event

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.EventsEntity
import com.aria.footballapp.viewmodel.DetailEventViewModel
import com.aria.footballapp.viewmodel.ViewModelFactory
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_event.*
import kotlinx.android.synthetic.main.container_cv_detail_event.*
import java.text.SimpleDateFormat
import java.util.*

class DetailEventActivity : AppCompatActivity() {

    private lateinit var tvTeamsHome: TextView
    private lateinit var tvTeamAway: TextView
    private lateinit var tvScoreHome: TextView
    private lateinit var tvScoreAway: TextView
    private lateinit var tvGoalHome: TextView
    private lateinit var tvGoalAway: TextView
    private lateinit var tvYellowHome: TextView
    private lateinit var tvYellowAway: TextView
    private lateinit var tvRedAway: TextView
    private lateinit var tvRedHome: TextView
    private lateinit var tvDate: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var container: LinearLayout
    private lateinit var imgHomeBadge: ImageView
    private lateinit var imgAwayBadge: ImageView
    private lateinit var imgBanner: ImageView

    private lateinit var viewModel: DetailEventViewModel

    companion object {
        fun obtainViewModel(activity: AppCompatActivity): DetailEventViewModel {
            val factory: ViewModelFactory? = ViewModelFactory.instance(activity.application)
            return ViewModelProviders.of(activity, factory).get(DetailEventViewModel::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_event)

        initUI()
        showLoading(true)

        val eventId: String = intent.getStringExtra("id")
        val idHome: String = intent.getStringExtra("home")
        val idAway: String = intent.getStringExtra("away")

        viewModel = obtainViewModel(this)
        viewModel.initEvent(eventId)
        viewModel.getDetailEvent()?.observe(this, Observer { event ->
            if (event != null) {
                populateEvents(event)
                showLoading(false)
            } else {
                showLoading(false)
                showError()
            }
        })

        viewModel.initTeam(idHome, idAway)
        viewModel.getHomeBadge()?.observe(this, Observer { badge ->
            badge.strTeamBadge?.let { Picasso.get().load(it).fit().into(imgHomeBadge) }
            badge.strStadiumThumb?.let { Picasso.get().load(it).fit().into(imgBanner) }
        })
        viewModel.getAwayBadge()?.observe(this, Observer { badge ->
            badge.strTeamBadge?.let { Picasso.get().load(it).fit().into(imgAwayBadge) }
        })
    }

    private fun initUI() {
        tvTeamsHome = tv_team_home
        tvTeamAway = tv_team_away
        tvScoreHome = tv_score_home
        tvScoreAway = tv_score_away
        tvGoalHome = tv_goals_home
        tvGoalAway = tv_goal_away
        tvYellowHome = tv_yellow_home
        tvYellowAway = tv_yellow_away
        tvRedHome = tv_red_home
        tvRedAway = tv_red_away
        tvDate = tv_event_date
        progressBar = progress_bar
        container = container_event
        imgHomeBadge = img_team_home
        imgAwayBadge = img_team_away
        imgBanner = img_banner_stadium
    }

    private fun populateEvents(event: EventsEntity) {
        tvTeamsHome.text = event.strHomeTeam
        tvTeamAway.text = event.strAwayTeam
        tvScoreHome.text = event.intHomeScore
        tvScoreAway.text = event.intAwayScore
        tvGoalHome.text = event.strHomeGoalDetails
        tvGoalAway.text = event.strAwayGoalDetails
        tvYellowHome.text = event.strHomeYellowCards
        tvYellowAway.text = event.strAwayYellowCards
        tvRedHome.text = event.strHomeRedCards
        tvRedAway.text = event.strAwayRedCards

        val dateConvert = toGMTFormat(event.dateEvent, event.strTime)
        val formatDate = SimpleDateFormat("E, dd/MM")
        val date = formatDate.format(dateConvert)

        tvDate.text = date

        if (event.intHomeScore == null && event.intAwayScore == null) {
            Toast.makeText(this, "The match hasn't started yet", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
            container.visibility = View.INVISIBLE
        } else {
            progressBar.visibility = View.GONE
            container.visibility = View.VISIBLE
        }
    }

    private fun showError() {
        Toast.makeText(this, "Please check your connection", Toast.LENGTH_SHORT).show()
    }

    private fun toGMTFormat(date: String?, time: String?): Date {
        val convert = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        convert.timeZone = TimeZone.getTimeZone("UTC")
        val dateTime = "$date $time"
        return convert.parse(dateTime)
    }
}
