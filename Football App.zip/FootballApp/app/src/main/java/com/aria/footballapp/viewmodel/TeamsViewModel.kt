package com.aria.footballapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.data.source.local.entity.TeamsEntity

class TeamsViewModel(private val footballRepository: FootballRepository?) : ViewModel() {

    var data: LiveData<List<TeamsEntity>>? = null

    fun initTeams(league: String) {
        if (data != null) {
            return
        }

        data = footballRepository?.getAllTeams(league)
    }

    fun getAllTeams(): LiveData<List<TeamsEntity>>? {
        return data
    }
}