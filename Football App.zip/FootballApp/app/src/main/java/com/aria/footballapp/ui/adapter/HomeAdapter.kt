package com.aria.footballapp.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aria.footballapp.R
import com.aria.footballapp.data.source.local.entity.LeaguesEntity
import com.aria.footballapp.ui.league.DetailLeagueActivity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.list_league.view.*
import org.jetbrains.anko.startActivity

class HomeAdapter(private val context: Context) :
    RecyclerView.Adapter<HomeAdapter.HomeViewHolder>() {

    private val items: MutableList<LeaguesEntity> = ArrayList()
    fun setList(items: List<LeaguesEntity>) {
        this.items.clear()
        this.items.addAll(items)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        return HomeViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.list_league,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        holder.bindItem(context, items[position])
    }

    class HomeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle = itemView.tv_item_league_name
        private val tvInformation = itemView.tv_item_information
        private val imgBadge = itemView.img_item_league
        private val cardView = itemView.cv_league_list

        fun bindItem(context: Context, items: LeaguesEntity) {
            tvTitle.text = items.strLeague
            tvInformation.text = items.strDescriptionEN
            items.strBadge?.let { Picasso.get().load(it).fit().into(imgBadge) }

            cardView.setOnClickListener {
                context.startActivity<DetailLeagueActivity>(
                    "id" to items.idLeague,
                    "league" to items.strLeague
                )
            }
        }
    }

}