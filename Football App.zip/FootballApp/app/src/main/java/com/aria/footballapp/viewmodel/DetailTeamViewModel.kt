package com.aria.footballapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aria.footballapp.data.source.FootballRepository
import com.aria.footballapp.data.source.local.entity.TeamsEntity

class DetailTeamViewModel(private val footballRepository: FootballRepository?) : ViewModel() {

    var data: LiveData<TeamsEntity>? = null

    fun initTeam(teamId: String) {
        if (data != null) {
            return
        }

        data = footballRepository?.getDetailTeam(teamId)
    }

    fun getTeams(): LiveData<TeamsEntity>? {
        return data
    }
}